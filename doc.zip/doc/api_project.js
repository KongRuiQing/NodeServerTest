define({
  "name": "ApiDoc",
  "version": "0.0.1",
  "description": "",
  "title": "闪寻项目的api说明",
  "url": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-03-27T13:47:26.869Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
