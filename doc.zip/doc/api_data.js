define({ "api": [
  {
    "type": "post",
    "url": "/admin/v1/ad/",
    "title": "AdImage",
    "name": "_v1_ad",
    "group": "Ad",
    "version": "0.0.1",
    "description": "<p>通知广告位发生变化</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "position",
            "description": "<p>广告位的位置,对应以下几个枚举 0 首页 1 活动 2 我的 3 行程.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "index",
            "description": "<p>广告位的顺序,取值范围0-5,一共6个.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "image",
            "description": "<p>广告位图片地址</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "url",
            "description": "<p>链接地址</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n\tposition:1,\n\tindex:1,\n\timage:\"ad/1.png\",\n\turl:'http://www.baidu.com'\n}",
          "type": "json"
        },
        {
          "title": "Request-Example:",
          "content": "{\n\tposition:1,\n\tindex:1,\n}",
          "type": "json"
        }
      ]
    },
    "examples": [
      {
        "title": "usage:",
        "content": "http://139.224.227.82:12000/admin/v1/ad",
        "type": "http"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "error",
            "description": "<p>错误号,返回0表示没有错误</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "error_msg",
            "description": "<p>错误详细信息</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response-Success-Example:",
          "content": "{\n\t error:0\n}",
          "type": "json"
        },
        {
          "title": "Response-Error-Example:",
          "content": "{\n\t error:1,\n\t error_msg:'没有指定type字段'\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./http_notify.js",
    "groupTitle": "Ad"
  },
  {
    "type": "post",
    "url": "/v1/area/",
    "title": "Area",
    "name": "_v1_area",
    "group": "Area",
    "version": "0.0.1",
    "description": "<p>通知区域发生变化</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "type",
            "description": "<p>操作类型 0 表示删除,1表示修改,2表示添加</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "province",
            "description": "<p>省份 [area_menu.province]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "city",
            "description": "<p>城市代码 [area_menu.city]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>区域名字,如果code为0,代表是city的名字 [area_menu.name]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>区域代码,一般是city的编码*1000+索引号构成,如大连的代码是167,那么区域编码从167001开始到 167999 [area_menu.code], 如果type是0表示删除的话,则以这个参数为标准</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n \ttype:1\n\tprovince:6,\n\tcity:167,\n\tname:'中山区',\n\tcode:167001\n}",
          "type": "json"
        },
        {
          "title": "Request-Example:",
          "content": "{\n \ttype:0\n\tcode:167001 // 删除code为167001的区域\n}",
          "type": "json"
        }
      ]
    },
    "examples": [
      {
        "title": "usage:",
        "content": "http://139.224.227.82:9891/admin/v1/area",
        "type": "http"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "error",
            "description": "<p>错误号,返回0表示没有错误</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "error_msg",
            "description": "<p>错误详细信息</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response-Example-1",
          "content": "{\n\t error:0\n}",
          "type": "json"
        },
        {
          "title": "Response-Example-2",
          "content": "{\n\t error:1\n\t error_msg:'没有指定city',\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./http_notify.js",
    "groupTitle": "Area"
  },
  {
    "type": "post",
    "url": "/v1/category/",
    "title": "Category",
    "name": "_v1_category",
    "group": "Category",
    "version": "0.0.1",
    "description": "<p>通知分类发生变化</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "class",
            "description": "<p>上一级菜单 [category_menu.class]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>菜单名字 [category_menu.name]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>菜单代码</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n\tclass:1,\n\tname:'餐饮',\n\tcode:167001\n}",
          "type": "json"
        }
      ]
    },
    "examples": [
      {
        "title": "usage:",
        "content": "http://139.224.227.82:9891/admin/v1/category",
        "type": "http"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "error",
            "description": "<p>错误号,返回0表示没有错误</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "error_msg",
            "description": "<p>错误详细信息</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response-Example-1",
          "content": "{\n\t error:0\n}",
          "type": "json"
        },
        {
          "title": "Response-Example-2",
          "content": "{\n\t error:1\n\t error_msg:'name',\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./http_notify.js",
    "groupTitle": "Category"
  },
  {
    "type": "post",
    "url": "/v1/shop/",
    "title": "shop",
    "name": "_v1_shop",
    "group": "Shop",
    "version": "0.0.0",
    "description": "<p>shop.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "type",
            "description": "<p>0:删除指定ID的商铺;1:修改指定ID的商铺,2:添加商铺</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>对应商铺的id,参见上面参数对应的意义 [shop.id]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>对应商铺的名字.[shop.name]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "city_no",
            "description": "<p>对应商铺的名字.[shop.city_no]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "area_code",
            "description": "<p>地区代码信息.[shop.area_code] = [area_menu.code]</p>"
          },
          {
            "group": "Parameter",
            "type": "[Number]",
            "optional": false,
            "field": "category1",
            "description": "<p>商铺的分类.[shop.category_code1] = [category_menu.code]</p>"
          },
          {
            "group": "Parameter",
            "type": "[Number]",
            "optional": false,
            "field": "category2",
            "description": "<p>商铺的分类.[shop.category_code2] = [category_menu.code]</p>"
          },
          {
            "group": "Parameter",
            "type": "[Number]",
            "optional": false,
            "field": "category3",
            "description": "<p>商铺的分类.[shop.category_code3] = [category_menu.code]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "beg",
            "description": "<p>营业的开始时间,计算方式为今天开业的时间以s为单位.[shop.beg]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "end",
            "description": "<p>营业的结束时间,计算方式为今天开业的时间以s为单位.[shop.end]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "days",
            "description": "<p>营业的一周内的周几,(1111111:7天全营业;0000001 只有周1) [shop.days]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "telephone",
            "description": "<p>联系电话.[shop.telephone]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>电邮地址.[shop.email]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "qq",
            "description": "<p>电邮地址.[shop.qq]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "wx",
            "description": "<p>电邮地址.[shop.wx]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "longitude",
            "description": "<p>经度.[shop.longitude]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "latitude",
            "description": "<p>纬度.[shop.latitude]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>地址.[shop.address]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "distribution",
            "description": "<p>配送地址.[shop.distribution]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "info",
            "description": "<p>商家介绍.[shop.info]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "qualification",
            "description": "<p>资质认证,营业执照[shop.qualification]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "card_number",
            "description": "<p>身份证号[shop.card_number]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "card_image",
            "description": "<p>本人照片显示 [shop.card_image]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "image",
            "description": "<p>商铺图片 [shop.image]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "state",
            "description": "<p>0未通过审核，1通过审核</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "usage:",
        "content": "http://139.224.227.82:9891/admin/v1/shop",
        "type": "http"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "error",
            "description": "<p>错误号,返回0表示没有错误</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "error_msg",
            "description": "<p>错误详细信息</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response-Error-Example:",
          "content": "{\n\t error:1,\n\t error_msg:'没有指定type字段'\n}",
          "type": "json"
        },
        {
          "title": "Response-Success-Example:",
          "content": "{\n\t error:0\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./http_notify.js",
    "groupTitle": "Shop"
  },
  {
    "type": "post",
    "url": "/v1/shop_item/",
    "title": "shop_item",
    "name": "_v1_shop_item",
    "group": "Shop",
    "version": "0.0.1",
    "description": "<p>修改或添加商铺物品</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "type",
            "description": "<p>0:删除指定ID; 1:修改指定ID; 2:添加,没有id;</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>商铺id [shop_item.id]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>物品的名字 [shop_item.name]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "price",
            "description": "<p>物品的价格 [shop_item.price]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "show_price",
            "description": "<p>物品打拆后的价格 [shop_item.show_price]</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "is_show",
            "description": "<p>如果是1的话,表示是一店优品,要展示在前台首页 [shop_item.is_show]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "spread_image",
            "description": "<p>显示在app首页里的图片,推广图片.shop_item_image.image -&gt;[shop_item_image.image_type = 1]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "show_image",
            "description": "<p>列表,展示图片 [shop_item_image.image] -&gt;[shop_item_image.image_type = 2]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "detail_image",
            "description": "<p>列表,细节图片 [shop_item_image.image] -&gt;[shop_item_image.image_type = 3]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "link_url",
            "description": "<p>直达链接</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n \ttype:0\n \tid:2\n}\n添加物品",
          "type": "json"
        },
        {
          "title": "Request-Example:",
          "content": "{\n \ttype:1\n \tid:2\n\tname:'商品1',\n\tprice:100,\n\tshow_price:80,\n\tis_show:false,\n\timages:[\n\t\t'shop/item/1.png',\n\t\t'shop/item/2.png'\n\t],\n\tshow_image:[\n\t\t'shop/spread/1.png',\n\t],\n\tdetail_image:[\n\t\t'shop/item/1.png',\n\t\t'shop/item/2.png',\n\t],\n\tlink_url:'www.baidu.com'\n}",
          "type": "json"
        }
      ]
    },
    "examples": [
      {
        "title": "usage:",
        "content": "http://139.224.227.82:9891/admin/v1/shop_item",
        "type": "http"
      }
    ],
    "filename": "./http_notify.js",
    "groupTitle": "Shop"
  }
] });
